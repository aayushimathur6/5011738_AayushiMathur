public class FinancialForecasting {
    // Recursive method to predict future value based on past growth rates
    public static double predictFutureValue(double currentValue, double growthRate, int periods) {
        // Base case: no more periods to predict
        if (periods == 0) {
            return currentValue;
        }
        double nextValue = currentValue * (1 + growthRate);
        return predictFutureValue(nextValue, growthRate, periods - 1);
    }

    // Main method to test the recursive prediction
    public static void main(String[] args) {
        // Example starting value
        double currentValue = 1000;
        // Example growth rate (5%)
        double growthRate = 0.05;
        // Example number of periods
        int periods = 10;

        double predictedValue = predictFutureValue(currentValue, growthRate, periods);
        System.out.println("Predicted future value after " + periods + " periods: " + predictedValue);
    }
}
