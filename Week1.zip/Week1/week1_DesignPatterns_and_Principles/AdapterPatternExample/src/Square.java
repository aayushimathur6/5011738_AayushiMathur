public class Square {
    public void initiatePayment(double amount) {
        System.out.println("Processing payment through Square: $" + amount);
    }
}
