public class Stripe {
    public void charge(double amount) {
        System.out.println("Processing payment through Stripe: $" + amount);
    }
}
