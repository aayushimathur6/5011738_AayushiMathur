public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(String id) {
        // Simulating database access
        return new Customer(id, "John Doe");
    }
}