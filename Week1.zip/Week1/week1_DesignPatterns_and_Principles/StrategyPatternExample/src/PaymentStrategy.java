//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
// PaymentStrategy.java
public interface PaymentStrategy {
    void pay(double amount);
}
